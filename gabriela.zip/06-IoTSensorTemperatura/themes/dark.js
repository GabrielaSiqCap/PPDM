export const darkTheme = {
    background: "#000000",
    card: "#FFDEDE",
    text: "#CF0F47",
    label: "#FFDEDE",
    border: "#444",
    buttonPrimary: "#3399ff",
    buttonDanger: "#ff4d4d",
    result: "#66ccff",
    infoBg: "#1e1e1e",
    infoBorder: "#333",
  };