export const lightTheme = {
    background: "#F7F7F7",
    card: "#FFDEDE",
    text: "#FF0B55",
    label: "#000000",
    border: "#ccc",
    buttonPrimary: "#007bff",
    buttonDanger: "#dc3545",
    result: "#000000",
    infoBg: "#ffffff",
    infoBorder: "#eee",
  };
